package com.example.mylottieapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {
    Button bZ1, bZ2, bZ3, bZ4;
    ImageView iZ1, iZ2;
    Animation up_down_cont, right_to_left_cont;
    LottieAnimationView lA1, lA2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bZ1 = findViewById(R.id.bZ1);
        bZ2 = findViewById(R.id.bZ2);
        bZ3 = findViewById(R.id.bZ3);
        bZ4 = findViewById(R.id.bZ4);
        iZ1 = findViewById(R.id.iZ1);
        iZ2 = findViewById(R.id.iZ2);
        up_down_cont = AnimationUtils.loadAnimation(MainActivity.this,R.anim.up_down_cont);
        right_to_left_cont =AnimationUtils.loadAnimation(MainActivity.this,R.anim.right_to_left_cont);
        lA1 = findViewById(R.id.lA1);
        lA2 = findViewById(R.id.lA2);

        bZ1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                iZ1.startAnimation(up_down_cont);

            }
        });

        iZ1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Zurich is so beautiful",Toast.LENGTH_LONG).show();
            }
        });

        bZ2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                iZ2.startAnimation(right_to_left_cont);

            }
        });

        iZ2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Zurich is one of my dream home",Toast.LENGTH_LONG).show();
            }
        });

        bZ3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

             lA1.setAnimationFromUrl("https://assets9.lottiefiles.com/packages/lf20_6dvhclex.json");
             lA1.playAnimation();
             lA1.loop(true);
             lA1.pauseAnimation();



            }
        });

        bZ4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                lA2.setAnimation(R.raw.skeleton_dance);
                lA2.playAnimation();
                lA2.loop(true);
                lA2.pauseAnimation();


            }
        });

    }
}