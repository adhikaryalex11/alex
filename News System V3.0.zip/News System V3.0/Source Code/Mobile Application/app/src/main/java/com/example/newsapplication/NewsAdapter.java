package com.example.newsapplication;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder>{
    private Context mContext;
    private ArrayList<NewsModel> mNewsArrayList;

    public NewsAdapter(Context context, ArrayList<NewsModel> newsArrayList) {
        mContext = context;
        mNewsArrayList = newsArrayList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.row_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsModel newsModel = mNewsArrayList.get(position);

        String id = newsModel.getId();
        String title = newsModel.getTitle();
        String des = newsModel.getDescription();
        String img = newsModel.getImg();

        holder.title.setText(title);
        holder.des.setText(des);

        Picasso.get().load(img).into( holder.img);

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenDeleteConfirmDialog(id);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mNewsArrayList.size();
    }

    public class NewsViewHolder extends RecyclerView.ViewHolder {
        public TextView title, des;
        public ImageView img, delete;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.row_news_title);
            delete = itemView.findViewById(R.id.row_news_delete);
            img = itemView.findViewById(R.id.row_news_img);
            des = itemView.findViewById(R.id.row_news_des);
        }
    }

    private void OpenDeleteConfirmDialog(String orderID)
    {
        final Dialog deleteconfirmdialog = new Dialog(mContext);
        deleteconfirmdialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        deleteconfirmdialog.setContentView(R.layout.confirm_layout);
        deleteconfirmdialog.setTitle("Delete Confirm Dialog");
        deleteconfirmdialog.show();

        TextView title = (TextView)deleteconfirmdialog.findViewById(R.id.confirm_dialog_title);
        title.setText("Delete News");

        TextView description = (TextView)deleteconfirmdialog.findViewById(R.id.confirm_dialog_description);
        description.setText("Are you sure you want to delete news?");

        Button noBtn = (Button) deleteconfirmdialog.findViewById(R.id.confirm_dialog_no_button);
        noBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                deleteconfirmdialog.cancel();
            }
        });


        Button yesBtn = (Button) deleteconfirmdialog.findViewById(R.id.confirm_dialog_yes_button);
        yesBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                DeleteNews(orderID, deleteconfirmdialog);
            }
        });
    }

    private void DeleteNews(String newsID, Dialog dialog) {
        /* IP Address = Wireless LAN adapter Wi-Fi: IPv4 Address */
        String URL = "http://192.168.8.106/news-api/api/delete-news.php?id="+newsID;
        RequestQueue queue = Volley.newRequestQueue(mContext);
        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.DELETE, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.equals("[\"Deleted\"]")){
                    dialog.cancel();
                    Intent mainIntent = new Intent(mContext, MainActivity.class);
                    mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    mContext.startActivity(mainIntent);
                } else {
                    dialog.cancel();
                    Toast.makeText(mContext, "Failed.", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.cancel();
                Toast.makeText(mContext, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }
}
