package com.example.newsapplication;

import static android.content.Context.MODE_PRIVATE;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ProfileFragment extends Fragment {

    private View view;

    private TextView textViewEmail, logoutBtn;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileFragment() {
        // Required empty public constructor
    }

    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_profile, container, false);

        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("Shared Pref", MODE_PRIVATE);
        String userEmail = sharedPreferences.getString("userEmail", "");

        textViewEmail = view.findViewById(R.id.profile_email);
        textViewEmail.setText(userEmail);

        logoutBtn = view.findViewById(R.id.logout_btn);
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenConfirmDialog();
            }
        });
        return view;
    }

    private void OpenConfirmDialog()
    {
        final Dialog confirmDialog = new Dialog(getContext());
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        confirmDialog.setContentView(R.layout.confirm_layout);
        confirmDialog.setTitle("Confirm Dialog");
        confirmDialog.show();

        TextView title = (TextView)confirmDialog.findViewById(R.id.confirm_dialog_title);
        title.setText("Logout");

        TextView description = (TextView)confirmDialog.findViewById(R.id.confirm_dialog_description);
        description.setText("Are you sure you want to logout?");

        Button noBtn = (Button) confirmDialog.findViewById(R.id.confirm_dialog_no_button);
        noBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                confirmDialog.cancel();
            }
        });


        Button yesBtn = (Button) confirmDialog.findViewById(R.id.confirm_dialog_yes_button);
        yesBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Shared Pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("userEmail", "");
                editor.apply();

                Intent loginIntent = new Intent(getContext(), LoginActivity.class);
                loginIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(loginIntent);
            }
        });
    }
}