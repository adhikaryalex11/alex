<?php
    class News{
        private $con;
        private $table ="news";

        public $id;
        public $title;
        public $description;
        public $img;
        
        public function __construct($db) {
            $this->con = $db;
        }

        public function get_all() {
            $query = 'SELECT * FROM '.$this->table.'';
    
            $stmt = $this -> con -> prepare($query);
    
            $stmt->execute();
    
            return $stmt;
        }

        
        public function delete_news() {
            $query = 'DELETE FROM '.$this->table.' WHERE id=?';

            $stmt = $this -> con -> prepare($query);

            $this->id = htmlspecialchars(strip_tags($this->id));
      
            $stmt->bindParam(1,$this->id);

            if($stmt->execute()) {
                return true;
            }

            printf("Error %s. \n", $stmt->error);
            return false;
        }
    }