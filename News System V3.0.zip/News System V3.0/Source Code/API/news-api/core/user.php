<?php
    class User{
        private $con;
        private $table ="user";

        public $email;
        public $password;
        
        public function __construct($db) {
            $this->con = $db;
        }

        public function login() {
            $query = 'SELECT * FROM '.$this->table.' WHERE email=:email AND password=:password';

            $stmt = $this -> con -> prepare($query);

            $this->email = htmlspecialchars(strip_tags($this->email));
            $this->password = htmlspecialchars(strip_tags($this->password));

            $stmt->bindParam(':email', $this->email);
            $stmt->bindParam(':password', $this->password);

            $stmt->execute();

            return $stmt;
        }

        public function register() {
            $query = 'INSERT INTO '.$this->table.'(email, password)
            VALUES (:email, :password)';

            $stmt = $this -> con -> prepare($query);

            $this->email = htmlspecialchars(strip_tags($this->email));
            $this->password = htmlspecialchars(strip_tags($this->password));

            $stmt->bindParam(':email', $this->email);
            $stmt->bindParam(':password', $this->password);

            if($stmt->execute()) {
                return true;
            }

            printf("Error %s. \n", $stmt->error);
            return false;
        }
    }