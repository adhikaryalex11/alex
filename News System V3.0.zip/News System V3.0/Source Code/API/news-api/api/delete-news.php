<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: DELETE');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

    include_once('../core/initialize.php');

    $news = new News($db);

    $news->id = isset($_GET['id']) ? $_GET['id'] : die();

    if($news->delete_news()) {
        echo json_encode(
            array('Deleted')
        );
    } else {
        echo json_encode(
            array('Failed')
        );
    }