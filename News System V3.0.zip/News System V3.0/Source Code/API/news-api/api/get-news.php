<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');

    include_once('../core/initialize.php');

    $news = new News($db);

    $result = $news->get_all();

    $num = $result->rowCount();

    if($num > 0) {
        $news_arr = array();

        while($row = $result->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $news_item = array (
                'id' => $id,
                'title' => $title,
                'description' => $description,
                'img' => $img
            );
           array_push($news_arr, $news_item);
        }
        echo json_encode($news_arr);
    }
    else {
        echo json_encode(array('message' => 'empty'));
    }