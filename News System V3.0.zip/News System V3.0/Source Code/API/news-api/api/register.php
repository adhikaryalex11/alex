<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

    include_once('../core/initialize.php');

    $user = new User($db);

    $user->email = isset($_GET['email']) ? $_GET['email'] : die();
    $user->password = isset($_GET['password']) ? $_GET['password'] : die();

    if(($user->password) != "") {
        if($user->register()) {
            echo json_encode(
                array('Registration Successfully')
            );
        } else {
            echo json_encode(
                array('Registration Failed')
            );
        }
    }