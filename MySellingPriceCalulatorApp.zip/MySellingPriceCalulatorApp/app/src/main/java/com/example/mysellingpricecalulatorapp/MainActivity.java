package com.example.mysellingpricecalulatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edBuy, edProfit;
    Button bCal;
    TextView tvDisplay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edBuy = findViewById(R.id.edBuy);
        edProfit = findViewById(R.id.edProfit);
        bCal = findViewById(R.id.bCal);
        tvDisplay = findViewById(R.id.tvDisplay);


        bCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               float buyPrice, profitPercent, sellPrice, profit;

               String sBuyPrice = edBuy.getText().toString();
               buyPrice = Float.parseFloat(sBuyPrice);

               profitPercent = Float.parseFloat(edProfit.getText().toString());

               sellPrice = ((100+profitPercent)/100)*buyPrice;

               profit = (profitPercent/100)*buyPrice;

               tvDisplay.setText("The estimated selling price will be = "+sellPrice+"\n Then the profit will be = "+profit);

            }
        });





    }
}