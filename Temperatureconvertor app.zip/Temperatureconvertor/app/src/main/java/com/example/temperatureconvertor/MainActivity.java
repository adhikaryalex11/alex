package com.example.temperatureconvertor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edFarenheit, edCelsius;
    Button bCelsius, bFarenheit ;
    TextView tvDisplay1, tvDisplay2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edFarenheit = findViewById(R.id.edFarenheit);
        edCelsius = findViewById(R.id.edCelsius);
        bFarenheit = findViewById(R.id.bFarenheit);
        bCelsius = findViewById(R.id.bCelsius);
        tvDisplay1 = findViewById(R.id.tvDisplay1);
        tvDisplay2 = findViewById(R.id.tvDisplay2);



        bFarenheit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String celsius1;

                celsius1 = edCelsius.getText().toString();

                double celsius2, cFarenheit;

                celsius2 = Double.parseDouble(celsius1);

                cFarenheit = (celsius2 * 1.8) + 32;

                tvDisplay1.setText(" The farenheit temperature is : "+cFarenheit);
                Toast.makeText(MainActivity.this, "The celsius temperature given is successfully converted.", Toast.LENGTH_LONG).show();

            }
        });

        bCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               double farenheit2, cCelsius;

               farenheit2 = Double.parseDouble(edFarenheit.getText().toString());

              cCelsius = (farenheit2-32)/1.8;

               tvDisplay2.setText(" The celsius temperature is : "+cCelsius);
                Toast.makeText(MainActivity.this, "The farenheit temperature given is successfully converted.", Toast.LENGTH_LONG).show();


            }
        });

    }
}