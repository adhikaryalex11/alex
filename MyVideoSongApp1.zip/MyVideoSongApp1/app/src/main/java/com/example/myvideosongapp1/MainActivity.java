package com.example.myvideosongapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout songLayout1, songLayout2, songLayout3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        songLayout1 = findViewById(R.id.songLayout1);
        songLayout2 = findViewById(R.id.songLayout2);
        songLayout3 = findViewById(R.id.songLayout3);

        songLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoPlayer.video_url = "https://www.youtube.com/embed/MeUuYemBmmk";
                Intent myIntent = new Intent (MainActivity.this, VideoPlayer.class);
                startActivity(myIntent);
            }
        });

        songLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoPlayer.video_url = "https://www.youtube.com/embed/u_wB6byrl5k";
                Intent myIntent = new Intent (MainActivity.this, VideoPlayer.class);
                startActivity(myIntent);
            }
        });

        songLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoPlayer.video_url = "https://www.youtube.com/embed/H0XvcHOJNNA";
                Intent myIntent = new Intent(MainActivity.this, VideoPlayer.class);
                startActivity(myIntent);
            }
        });

    }
}